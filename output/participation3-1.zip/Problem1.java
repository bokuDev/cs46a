public class Problem1 {
    public static void main(String[] args) {
        String testString = "Hello, again!";
        System.out.println(testString.length()); // Prints 13
    }
}
